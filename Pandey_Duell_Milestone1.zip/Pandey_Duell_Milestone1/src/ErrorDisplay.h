#pragma once

class ErrorDisplay {
public:

private:

};