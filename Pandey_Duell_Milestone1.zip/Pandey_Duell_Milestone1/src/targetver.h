//
//targetver.h - Defines the targeted system for the application
//

#pragma once

//Targets latest version
#include <SDKDDKVer.h>