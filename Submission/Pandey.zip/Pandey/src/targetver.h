//
// targetver.h
// Defines the targeted system for the application
//

/*	************************************************************
* Name:			Vivek Pandey								*
* Project:		Duell C++									*
* Class:		CMPS 366									*
* Date:			10/4/2016									*
************************************************************ */

#pragma once

//Targets latest version
#include <SDKDDKVer.h>